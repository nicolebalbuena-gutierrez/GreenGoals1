const express = require('express');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const cors = require('cors');
const fs = require('fs');
const path = require('path');

const app = express();
const PORT = 3000;
const JWT_SECRET = 'greengoals-secret-key-2025';

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.static('public'));

// Database file path
const DB_PATH = path.join(__dirname, 'database.json');

// Helper functions to read/write database
function readDatabase() {
    const data = fs.readFileSync(DB_PATH, 'utf8');
    return JSON.parse(data);
}

function writeDatabase(data) {
    fs.writeFileSync(DB_PATH, JSON.stringify(data, null, 2));
}

// Auth middleware
function authenticateToken(req, res, next) {
    const authHeader = req.headers['authorization'];
    const token = authHeader && authHeader.split(' ')[1];
    if (!token) return res.status(401).json({ error: 'Access denied' });
    
    jwt.verify(token, JWT_SECRET, (err, user) => {
        if (err) return res.status(403).json({ error: 'Invalid token' });
        req.user = user;
        next();
    });
}

// Admin auth middleware
function authenticateAdmin(req, res, next) {
    const authHeader = req.headers['authorization'];
    const token = authHeader && authHeader.split(' ')[1];
    if (!token) return res.status(401).json({ error: 'Access denied' });
    
    jwt.verify(token, JWT_SECRET, (err, admin) => {
        if (err) return res.status(403).json({ error: 'Invalid token' });
        if (!admin.isAdmin) return res.status(403).json({ error: 'Admin access required' });
        req.admin = admin;
        next();
    });
}

// ============================================
// ADMIN AUTH ROUTES
// ============================================

// Admin login
app.post('/api/admin/login', async (req, res) => {
    try {
        const { email, password } = req.body;
        const db = readDatabase();

        const admin = db.admins.find(a => a.email === email);
        if (!admin) {
            return res.status(400).json({ error: 'Invalid admin credentials' });
        }

        // For first login, allow plain password, then hash it
        let isMatch = false;
        if (admin.password.startsWith('$2a$')) {
            isMatch = await bcrypt.compare(password, admin.password);
        } else {
            // Plain text password (first time setup)
            isMatch = password === admin.password;
            if (isMatch) {
                // Hash the password for future logins
                admin.password = await bcrypt.hash(password, 10);
                writeDatabase(db);
            }
        }

        if (!isMatch) {
            return res.status(400).json({ error: 'Invalid admin credentials' });
        }

        const token = jwt.sign({ 
            adminId: admin.id, 
            username: admin.username, 
            isAdmin: true 
        }, JWT_SECRET, { expiresIn: '8h' });

        res.json({ 
            message: 'Admin login successful!', 
            token,
            admin: { id: admin.id, username: admin.username, role: admin.role }
        });
    } catch (error) {
        res.status(500).json({ error: 'Server error during admin login' });
    }
});

// ============================================
// ADMIN MANAGEMENT ROUTES
// ============================================

// Add new challenge (admin only)
app.post('/api/admin/challenges', authenticateAdmin, (req, res) => {
    const { name, description, points, co2Saved, difficulty, category, duration } = req.body;
    const db = readDatabase();

    const newChallenge = {
        id: db.challenges.length > 0 ? Math.max(...db.challenges.map(c => c.id)) + 1 : 1,
        name,
        description,
        points: parseInt(points),
        co2Saved: parseFloat(co2Saved),
        difficulty,
        category,
        duration
    };

    db.challenges.push(newChallenge);
    writeDatabase(db);

    res.json({ message: 'Challenge created!', challenge: newChallenge });
});

// Edit challenge (admin only)
app.put('/api/admin/challenges/:id', authenticateAdmin, (req, res) => {
    const { name, description, points, co2Saved, difficulty, category, duration } = req.body;
    const db = readDatabase();
    const challengeId = parseInt(req.params.id);

    const challenge = db.challenges.find(c => c.id === challengeId);
    if (!challenge) {
        return res.status(404).json({ error: 'Challenge not found' });
    }

    if (name) challenge.name = name;
    if (description) challenge.description = description;
    if (points) challenge.points = parseInt(points);
    if (co2Saved) challenge.co2Saved = parseFloat(co2Saved);
    if (difficulty) challenge.difficulty = difficulty;
    if (category) challenge.category = category;
    if (duration) challenge.duration = duration;

    writeDatabase(db);
    res.json({ message: 'Challenge updated!', challenge });
});

// Delete challenge (admin only)
app.delete('/api/admin/challenges/:id', authenticateAdmin, (req, res) => {
    const db = readDatabase();
    const challengeId = parseInt(req.params.id);

    const index = db.challenges.findIndex(c => c.id === challengeId);
    if (index === -1) {
        return res.status(404).json({ error: 'Challenge not found' });
    }

    db.challenges.splice(index, 1);
    writeDatabase(db);
    res.json({ message: 'Challenge deleted!' });
});

// Get all users with full details (admin only)
app.get('/api/admin/users', authenticateAdmin, (req, res) => {
    const db = readDatabase();
    const users = db.users.map(user => ({
        id: user.id,
        firstName: user.firstName || '',
        lastName: user.lastName || '',
        username: user.username,
        classYear: user.classYear || '',
        email: user.email,
        profilePicture: user.profilePicture || '',
        bio: user.bio || '',
        points: user.points,
        totalCO2Saved: user.totalCO2Saved,
        joinedDate: user.joinedDate,
        teamId: user.teamId,
        activeChallenges: user.activeChallenges,
        completedChallenges: user.completedChallenges
    }));
    res.json(users);
});

// Edit user (admin only)
app.put('/api/admin/users/:id', authenticateAdmin, (req, res) => {
    const { firstName, lastName, username, classYear, email, points, bio } = req.body;
    const db = readDatabase();
    const userId = parseInt(req.params.id);

    const user = db.users.find(u => u.id === userId);
    if (!user) {
        return res.status(404).json({ error: 'User not found' });
    }

    if (firstName !== undefined) user.firstName = firstName;
    if (lastName !== undefined) user.lastName = lastName;
    if (username !== undefined) user.username = username;
    if (classYear !== undefined) user.classYear = classYear;
    if (email !== undefined) user.email = email;
    if (points !== undefined) user.points = parseInt(points);
    if (bio !== undefined) user.bio = bio;

    writeDatabase(db);
    res.json({ message: 'User updated!', user });
});

// Delete user (admin only)
app.delete('/api/admin/users/:id', authenticateAdmin, (req, res) => {
    const db = readDatabase();
    const userId = parseInt(req.params.id);

    const index = db.users.findIndex(u => u.id === userId);
    if (index === -1) {
        return res.status(404).json({ error: 'User not found' });
    }

    // Remove user from any teams
    const user = db.users[index];
    if (user.teamId) {
        const team = db.teams.find(t => t.id === user.teamId);
        if (team) {
            team.members = team.members.filter(id => id !== userId);
            team.totalPoints -= user.points;
        }
    }

    db.users.splice(index, 1);
    writeDatabase(db);
    res.json({ message: 'User deleted!' });
});

// Reset user password (admin only)
app.post('/api/admin/users/:id/reset-password', authenticateAdmin, async (req, res) => {
    const { newPassword } = req.body;
    const db = readDatabase();
    const userId = parseInt(req.params.id);

    const user = db.users.find(u => u.id === userId);
    if (!user) {
        return res.status(404).json({ error: 'User not found' });
    }

    user.password = await bcrypt.hash(newPassword, 10);
    writeDatabase(db);
    res.json({ message: 'Password reset successfully!' });
});

// ============================================
// AUTH ROUTES
// ============================================

// Register new user
app.post('/api/register', async (req, res) => {
    try {
        const { firstName, lastName, username, classYear, email, password } = req.body;
        const db = readDatabase();

        const existingUser = db.users.find(u => u.email === email || u.username === username);
        if (existingUser) {
            return res.status(400).json({ error: 'User already exists with this email or username' });
        }

        const hashedPassword = await bcrypt.hash(password, 10);

        const newUser = {
            id: db.users.length + 1,
            firstName,
            lastName,
            username,
            classYear: classYear || '',
            email,
            password: hashedPassword,
            profilePicture: '',
            bio: '',
            points: 0,
            totalCO2Saved: 0,
            joinedDate: new Date().toISOString().split('T')[0],
            teamId: null,
            activeChallenges: [],
            completedChallenges: []
        };

        db.users.push(newUser);
        writeDatabase(db);

        const token = jwt.sign({ userId: newUser.id, username: newUser.username }, JWT_SECRET, { expiresIn: '24h' });

        res.json({ 
            message: 'Registration successful!', 
            token,
            user: { id: newUser.id, username: newUser.username, email: newUser.email, points: newUser.points }
        });
    } catch (error) {
        res.status(500).json({ error: 'Server error during registration' });
    }
});

// Login user
app.post('/api/login', async (req, res) => {
    try {
        const { email, password } = req.body;
        const db = readDatabase();

        const user = db.users.find(u => u.email === email);
        if (!user) {
            return res.status(400).json({ error: 'Invalid email or password' });
        }

        const isMatch = await bcrypt.compare(password, user.password);
        if (!isMatch) {
            return res.status(400).json({ error: 'Invalid email or password' });
        }

        const token = jwt.sign({ userId: user.id, username: user.username }, JWT_SECRET, { expiresIn: '24h' });

        res.json({ 
            message: 'Login successful!', 
            token,
            user: { 
                id: user.id, 
                username: user.username, 
                email: user.email, 
                points: user.points,
                totalCO2Saved: user.totalCO2Saved,
                teamId: user.teamId
            }
        });
    } catch (error) {
        res.status(500).json({ error: 'Server error during login' });
    }
});

// ============================================
// LEADERBOARD ROUTES
// ============================================

// Get leaderboard (users sorted by points)
app.get('/api/leaderboard', (req, res) => {
    const db = readDatabase();
    const leaderboard = db.users
        .map(user => ({
            id: user.id,
            firstName: user.firstName || '',
            lastName: user.lastName || '',
            username: user.username,
            classYear: user.classYear || '',
            profilePicture: user.profilePicture || '',
            points: user.points,
            totalCO2Saved: user.totalCO2Saved,
            completedChallenges: user.completedChallenges.length,
            teamId: user.teamId
        }))
        .sort((a, b) => b.points - a.points);
    res.json(leaderboard);
});

// Get team leaderboard
app.get('/api/leaderboard/teams', (req, res) => {
    const db = readDatabase();
    const teamLeaderboard = db.teams
        .map(team => ({
            id: team.id,
            name: team.name,
            totalPoints: team.totalPoints,
            memberCount: team.members.length
        }))
        .sort((a, b) => b.totalPoints - a.totalPoints);
    res.json(teamLeaderboard);
});

// ============================================
// CHALLENGE ROUTES
// ============================================

// Get all challenges
app.get('/api/challenges', (req, res) => {
    const db = readDatabase();
    res.json(db.challenges);
});

// Accept a challenge
app.post('/api/challenges/:id/accept', authenticateToken, (req, res) => {
    const db = readDatabase();
    const challengeId = parseInt(req.params.id);
    const userId = req.user.userId;

    const user = db.users.find(u => u.id === userId);
    const challenge = db.challenges.find(c => c.id === challengeId);

    if (!challenge) {
        return res.status(404).json({ error: 'Challenge not found' });
    }

    if (user.activeChallenges.includes(challengeId)) {
        return res.status(400).json({ error: 'Challenge already active' });
    }

    if (user.completedChallenges.includes(challengeId)) {
        return res.status(400).json({ error: 'Challenge already completed' });
    }

    user.activeChallenges.push(challengeId);
    writeDatabase(db);

    res.json({ message: `Started challenge: ${challenge.name}`, activeChallenges: user.activeChallenges });
});

// Complete a challenge
app.post('/api/challenges/:id/complete', authenticateToken, (req, res) => {
    const db = readDatabase();
    const challengeId = parseInt(req.params.id);
    const userId = req.user.userId;

    const user = db.users.find(u => u.id === userId);
    const challenge = db.challenges.find(c => c.id === challengeId);

    if (!challenge) {
        return res.status(404).json({ error: 'Challenge not found' });
    }

    if (!user.activeChallenges.includes(challengeId)) {
        return res.status(400).json({ error: 'Challenge not active' });
    }

    // Remove from active, add to completed
    user.activeChallenges = user.activeChallenges.filter(id => id !== challengeId);
    user.completedChallenges.push(challengeId);
    user.points += challenge.points;
    user.totalCO2Saved += challenge.co2Saved;

    // Update team points if user is in a team
    if (user.teamId) {
        const team = db.teams.find(t => t.id === user.teamId);
        if (team) {
            team.totalPoints += challenge.points;
        }
    }

    writeDatabase(db);

    res.json({ 
        message: `Completed: ${challenge.name}! +${challenge.points} points, ${challenge.co2Saved}kg CO₂ saved!`,
        user: {
            points: user.points,
            totalCO2Saved: user.totalCO2Saved,
            completedChallenges: user.completedChallenges
        }
    });
});

// Get user's challenges
app.get('/api/user/challenges', authenticateToken, (req, res) => {
    const db = readDatabase();
    const user = db.users.find(u => u.id === req.user.userId);

    const activeChallenges = db.challenges.filter(c => user.activeChallenges.includes(c.id));
    const completedChallenges = db.challenges.filter(c => user.completedChallenges.includes(c.id));
    const availableChallenges = db.challenges.filter(c => 
        !user.activeChallenges.includes(c.id) && !user.completedChallenges.includes(c.id)
    );

    res.json({ activeChallenges, completedChallenges, availableChallenges });
});

// ============================================
// TEAM ROUTES
// ============================================

// Get all teams
app.get('/api/teams', (req, res) => {
    const db = readDatabase();
    const teams = db.teams.map(team => {
        const members = db.users.filter(u => team.members.includes(u.id)).map(u => ({
            id: u.id,
            username: u.username,
            points: u.points
        }));
        return { ...team, memberDetails: members };
    });
    res.json(teams);
});

// Create a team
app.post('/api/teams', authenticateToken, (req, res) => {
    const { name, description } = req.body;
    const db = readDatabase();
    const userId = req.user.userId;

    const user = db.users.find(u => u.id === userId);
    if (user.teamId) {
        return res.status(400).json({ error: 'You are already in a team' });
    }

    const newTeam = {
        id: db.teams.length + 1,
        name,
        description: description || '',
        members: [userId],
        totalPoints: user.points,
        createdDate: new Date().toISOString().split('T')[0]
    };

    db.teams.push(newTeam);
    user.teamId = newTeam.id;
    writeDatabase(db);

    res.json({ message: `Team "${name}" created!`, team: newTeam });
});

// Join a team
app.post('/api/teams/:id/join', authenticateToken, (req, res) => {
    const db = readDatabase();
    const teamId = parseInt(req.params.id);
    const userId = req.user.userId;

    const user = db.users.find(u => u.id === userId);
    const team = db.teams.find(t => t.id === teamId);

    if (!team) {
        return res.status(404).json({ error: 'Team not found' });
    }

    if (user.teamId) {
        return res.status(400).json({ error: 'You are already in a team' });
    }

    team.members.push(userId);
    team.totalPoints += user.points;
    user.teamId = teamId;
    writeDatabase(db);

    res.json({ message: `Joined team: ${team.name}!`, team });
});

// Leave a team
app.post('/api/teams/leave', authenticateToken, (req, res) => {
    const db = readDatabase();
    const userId = req.user.userId;

    const user = db.users.find(u => u.id === userId);
    if (!user.teamId) {
        return res.status(400).json({ error: 'You are not in a team' });
    }

    const team = db.teams.find(t => t.id === user.teamId);
    team.members = team.members.filter(id => id !== userId);
    team.totalPoints -= user.points;
    user.teamId = null;
    writeDatabase(db);

    res.json({ message: 'Left the team' });
});

// ============================================
// USER ROUTES
// ============================================

// Get all users (for admin view)
app.get('/api/users', (req, res) => {
    const db = readDatabase();
    const usersWithoutPasswords = db.users.map(user => ({
        id: user.id,
        firstName: user.firstName || '',
        lastName: user.lastName || '',
        username: user.username,
        email: user.email,
        points: user.points,
        totalCO2Saved: user.totalCO2Saved,
        joinedDate: user.joinedDate,
        teamId: user.teamId,
        activeChallenges: user.activeChallenges,
        completedChallenges: user.completedChallenges
    }));
    res.json(usersWithoutPasswords);
});

// Get user profile
app.get('/api/user/:id', (req, res) => {
    const db = readDatabase();
    const user = db.users.find(u => u.id === parseInt(req.params.id));
    if (!user) {
        return res.status(404).json({ error: 'User not found' });
    }

    const team = user.teamId ? db.teams.find(t => t.id === user.teamId) : null;
    const activeChallenges = db.challenges.filter(c => user.activeChallenges.includes(c.id));
    const completedChallenges = db.challenges.filter(c => user.completedChallenges.includes(c.id));

    res.json({
        id: user.id,
        firstName: user.firstName || '',
        lastName: user.lastName || '',
        username: user.username,
        classYear: user.classYear || '',
        email: user.email,
        profilePicture: user.profilePicture || '',
        bio: user.bio || '',
        points: user.points,
        totalCO2Saved: user.totalCO2Saved,
        joinedDate: user.joinedDate,
        team: team ? { id: team.id, name: team.name } : null,
        activeChallenges,
        completedChallenges
    });
});

// Update user profile
app.put('/api/user/profile', authenticateToken, (req, res) => {
    const { profilePicture, bio, classYear } = req.body;
    const db = readDatabase();
    const user = db.users.find(u => u.id === req.user.userId);
    
    if (!user) {
        return res.status(404).json({ error: 'User not found' });
    }

    if (profilePicture !== undefined) user.profilePicture = profilePicture;
    if (bio !== undefined) user.bio = bio;
    if (classYear !== undefined) user.classYear = classYear;

    writeDatabase(db);

    res.json({ 
        message: 'Profile updated!',
        user: {
            profilePicture: user.profilePicture,
            bio: user.bio,
            classYear: user.classYear
        }
    });
});

// Get raw database (FOR DEVELOPMENT)
app.get('/api/database/raw', (req, res) => {
    const db = readDatabase();
    res.json(db);
});

// ============================================
// STATS ROUTES
// ============================================

app.get('/api/stats', (req, res) => {
    const db = readDatabase();
    const totalUsers = db.users.length;
    const totalChallenges = db.challenges.length;
    const totalTeams = db.teams.length;
    const totalCO2Saved = db.users.reduce((sum, u) => sum + u.totalCO2Saved, 0);
    const totalPoints = db.users.reduce((sum, u) => sum + u.points, 0);

    res.json({
        totalUsers,
        totalChallenges,
        totalTeams,
        totalCO2Saved: totalCO2Saved.toFixed(1),
        totalPoints
    });
});

// Start server
app.listen(PORT, () => {
    console.log(`
    🌱 ═══════════════════════════════════════════════════════════════ 🌱
    
         ██████╗ ██████╗ ███████╗███████╗███╗   ██╗ ██████╗  ██████╗  █████╗ ██╗     ███████╗
        ██╔════╝ ██╔══██╗██╔════╝██╔════╝████╗  ██║██╔════╝ ██╔═══██╗██╔══██╗██║     ██╔════╝
        ██║  ███╗██████╔╝█████╗  █████╗  ██╔██╗ ██║██║  ███╗██║   ██║███████║██║     ███████╗
        ██║   ██║██╔══██╗██╔══╝  ██╔══╝  ██║╚██╗██║██║   ██║██║   ██║██╔══██║██║     ╚════██║
        ╚██████╔╝██║  ██║███████╗███████╗██║ ╚████║╚██████╔╝╚██████╔╝██║  ██║███████╗███████║
         ╚═════╝ ╚═╝  ╚═╝╚══════╝╚══════╝╚═╝  ╚═══╝ ╚═════╝  ╚═════╝ ╚═╝  ╚═╝╚══════╝╚══════╝
    
    🌱 ═══════════════════════════════════════════════════════════════ 🌱
    
    🌍 Server running at: http://localhost:${PORT}
    
    📁 PAGES:
       → Login/Register: http://localhost:${PORT}
       → Dashboard:      http://localhost:${PORT}/dashboard.html
       → Leaderboard:    http://localhost:${PORT}/leaderboard.html
       → Challenges:     http://localhost:${PORT}/challenges.html
    
    🔐 ADMIN:
       → Admin Login:    http://localhost:${PORT}/admin.html
       → Default Login:  admin@greengoals.com / admin123
    
    📊 API ENDPOINTS:
       → GET  /api/leaderboard       - User rankings
       → GET  /api/leaderboard/teams - Team rankings
       → GET  /api/challenges        - All challenges
       → GET  /api/teams             - All teams
       → GET  /api/stats             - Platform statistics
       → GET  /api/database/raw      - See everything!
    
    🌱 ═══════════════════════════════════════════════════════════════ 🌱
    `);
});
